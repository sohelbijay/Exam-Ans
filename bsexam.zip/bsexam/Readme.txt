Database Host : localhost
Database Name : bs_exam

Database User : root

Database Password :